package com.madhukaraphatak.yarnexamples.task

/**
 * Created by madhu on 16/12/14.
 */
object HelloWorld {
  def main(args: Array[String]) {
    println("helloworld")
  }

}
