package com.madhukaraphatak.yarnexamples.helloworld

/**
 * Created by madhu on 16/12/14.
 */
object HelloWorld {
  def main(args: Array[String]) {
    println("helloworld")
    Thread.sleep(10000)
  }

}
