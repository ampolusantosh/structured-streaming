package com.madhukaraphatak.yarnexamples.simpleakka

import java.io.File
import java.util.Collections

import akka.actor._
import com.typesafe.config.ConfigFactory
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FileSystem, Path}
import org.apache.hadoop.yarn.api.ApplicationConstants
import org.apache.hadoop.yarn.api.ApplicationConstants.Environment
import org.apache.hadoop.yarn.api.records.{ContainerLaunchContext, _}
import org.apache.hadoop.yarn.client.api.YarnClient
import org.apache.hadoop.yarn.conf.YarnConfiguration
import org.apache.hadoop.yarn.util.{Apps, ConverterUtils, Records}

import scala.collection.JavaConverters._
import scala.collection.mutable

/**
 * Created by madhu on 16/12/14.
 */
object Client {

  
  class RecieveActor extends Actor {
    import com.madhukaraphatak.yarnexamples.simpleakka.Client.RecieveActor._
    override def receive: Receive = {
      case Hi => {
        println("good to be here")
        context.stop(self)
      }
      case msg:String=>{
        println("received message:"+msg)
        context.stop(self)
      }
    }
  }
  
  object RecieveActor{
    object Hi extends Serializable
  }
  
  
  def setUpAppMasterJar(jarPath: Path, appMasterJar: LocalResource)(implicit conf:Configuration) = {
    val jarStat = FileSystem.get(conf).getFileStatus(jarPath)
    appMasterJar.setResource(ConverterUtils.getYarnUrlFromPath(jarPath))
    appMasterJar.setSize(jarStat.getLen())
    appMasterJar.setTimestamp(jarStat.getModificationTime())
    appMasterJar.setType(LocalResourceType.FILE)
    appMasterJar.setVisibility(LocalResourceVisibility.PUBLIC)
  }

  def setUpEnv(appMasterEnv: mutable.Map[String, String])(implicit conf:YarnConfiguration) = {
    val classPath = YarnConfiguration.DEFAULT_YARN_APPLICATION_CLASSPATH

    for (c <- classPath){
      Apps.addToEnvironment(appMasterEnv.asJava, Environment.CLASSPATH.name(),
        c.trim())
    }
    Apps.addToEnvironment(appMasterEnv.asJava,
      Environment.CLASSPATH.name(),
      Environment.PWD.$() + File.separator + "*")

  }

  def main(args: Array[String]) {

    implicit val conf = new YarnConfiguration()
    val jarPath = args(0)

    val client = YarnClient.createYarnClient()
    client.init(conf)
    client.start()

    println("inside the client")

    val app = client.createApplication()




    val taskFilePath ="hello"
    val config = ConfigFactory.parseFile(new File(Thread.currentThread().getContextClassLoader.
      getResource("remote_application.conf").getFile))
    println("config is" + config)
    val actorSystem = ActorSystem.create("actorSystemYarn",config)

    actorSystem.actorOf(Props[RecieveActor],name = "receiveActor")


    /*val serialization = SerializationExtension(actorSystem)

    val fileSystem = FileSystem.get(conf)
    val taskFilePath = "/tasks/"+UUID.randomUUID().toString
    val hdfsFile = fileSystem.create(new Path(taskFilePath))
    val out = new ObjectOutputStream(hdfsFile)
    out.write(serialization.findSerializerFor(recieveActorRef).toBinary(recieveActorRef))
    IOUtils.closeStream(out)
    IOUtils.closeStream(hdfsFile)
*/

    val amContainer = Records.newRecord(classOf[ContainerLaunchContext])
    amContainer.setCommands(List(
      "$JAVA_HOME/bin/java" +
      " -Xmx256M" +
      " com.madhukaraphatak.yarnexamples.akka.ApplicationMaster" +
        " " + taskFilePath +"  "+ jarPath+" "+
      " 1>" + ApplicationConstants.LOG_DIR_EXPANSION_VAR + "/stdout" +
      " 2>" + ApplicationConstants.LOG_DIR_EXPANSION_VAR + "/stderr"
    ).asJava)


    val appMasterJar = Records.newRecord(classOf[LocalResource])
    setUpAppMasterJar(new Path(jarPath),appMasterJar)


    amContainer.setLocalResources(Collections.singletonMap("helloworld.jar",appMasterJar))

    val env = collection.mutable.Map[String,String]()
    setUpEnv(env)
    amContainer.setEnvironment(env.asJava)

    val resource = Records.newRecord(classOf[Resource])
    resource.setMemory(300)
    resource.setVirtualCores(1)

    val appContext = app.getApplicationSubmissionContext
    appContext.setApplicationName("helloworld")
    appContext.setAMContainerSpec(amContainer)
    appContext.setResource(resource)
    appContext.setQueue("default")

    val appId = appContext.getApplicationId
    println("submitting application id" + appId)
    client.submitApplication(appContext)

  }

}
